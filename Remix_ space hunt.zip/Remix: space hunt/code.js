var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["848314f8-d7dc-4755-a4a1-3782173096b1","26b80e63-bc0f-408d-b288-be2282aebd4e","dfc53be7-786c-4305-b8eb-81fa595e9903","47fade86-5bd1-4789-87af-896fb1433a7b","043deebf-64b8-4795-be8d-db5055414f2f","c26b6449-0b6c-4483-8486-107c0091c26e","3221caad-ae37-4eec-92a8-56bae4769e66","c4e310e0-8174-4127-a46e-0cbcc94b488b","d1379f26-a36d-4b60-b684-87c9988a15c8","6b9462e5-dfcf-441c-9f20-524d652ba4c8","ebb12ed9-b027-4a88-8c4c-2cbabb86588c","86a08f63-af0a-4cc3-8ce2-0df5803643bc","ce9914eb-bfbd-4140-8e2e-06a59aaa8fed","dd7ed055-975a-4f2c-8b87-547bbee95b4c","1bf0370e-c715-44df-b29e-2a1d6f69a445"],"propsByKey":{"848314f8-d7dc-4755-a4a1-3782173096b1":{"name":"hero","sourceUrl":null,"frameSize":{"x":30,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"DuKIBOIOzk1hgJM2rZ.g17i6jpKc8Axs","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":30,"y":30},"rootRelativePath":"assets/848314f8-d7dc-4755-a4a1-3782173096b1.png"},"26b80e63-bc0f-408d-b288-be2282aebd4e":{"name":"enemy1","sourceUrl":null,"frameSize":{"x":35,"y":50},"frameCount":1,"looping":true,"frameDelay":12,"version":"z7JqYlJ0IVOhqMCb.BXHbSltT9O6fFvI","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":35,"y":50},"rootRelativePath":"assets/26b80e63-bc0f-408d-b288-be2282aebd4e.png"},"dfc53be7-786c-4305-b8eb-81fa595e9903":{"name":"enemy","sourceUrl":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png","frameSize":{"x":320,"y":254},"frameCount":1,"looping":true,"frameDelay":2,"version":"xasculQGiYxBV79ltD_0E79ZRIexdPdZ","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":320,"y":254},"rootRelativePath":"assets/api/v1/animation-library/gamelab/xasculQGiYxBV79ltD_0E79ZRIexdPdZ/category_food/american_hamburger.png"},"47fade86-5bd1-4789-87af-896fb1433a7b":{"name":"enemy2","sourceUrl":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png","frameSize":{"x":355,"y":241},"frameCount":1,"looping":true,"frameDelay":2,"version":"dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":355,"y":241},"rootRelativePath":"assets/api/v1/animation-library/gamelab/dVaFR7XFVlGQX4d.e71iiKWvnLhMbaxG/category_food/american_pastrami.png"},"043deebf-64b8-4795-be8d-db5055414f2f":{"name":"enemy3","sourceUrl":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png","frameSize":{"x":388,"y":388},"frameCount":1,"looping":true,"frameDelay":2,"version":"YSis4_lex43su6FLaL__bhoag4eHAl8D","categories":["food"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":388,"y":388},"rootRelativePath":"assets/api/v1/animation-library/gamelab/YSis4_lex43su6FLaL__bhoag4eHAl8D/category_food/american_bbqribs.png"},"c26b6449-0b6c-4483-8486-107c0091c26e":{"name":"hero1","sourceUrl":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png","frameSize":{"x":264,"y":368},"frameCount":1,"looping":true,"frameDelay":2,"version":"loycQXdICpzI4PfXITdIndG9GcVBmRdK","categories":["faces"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":264,"y":368},"rootRelativePath":"assets/api/v1/animation-library/gamelab/loycQXdICpzI4PfXITdIndG9GcVBmRdK/category_faces/kidportrait_01.png"},"3221caad-ae37-4eec-92a8-56bae4769e66":{"name":"b","sourceUrl":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png","frameSize":{"x":400,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/IJemJVUh3J1gcGlCdIJ8obCWhXAqxbUT/category_backgrounds/kitchen.png"},"c4e310e0-8174-4127-a46e-0cbcc94b488b":{"name":"dream","sourceUrl":null,"frameSize":{"x":386,"y":268},"frameCount":1,"looping":true,"frameDelay":12,"version":"ydwwFpoUk9riOhxILCLv1No68OAfBZ_e","categories":["icons"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":268},"rootRelativePath":"assets/c4e310e0-8174-4127-a46e-0cbcc94b488b.png"},"d1379f26-a36d-4b60-b684-87c9988a15c8":{"name":"vestroia","sourceUrl":"assets/api/v1/animation-library/gamelab/48WvIjYXVxyuCdt3Jah08koeLbeNGtRC/category_backgrounds/background_landscape11.png","frameSize":{"x":400,"y":399},"frameCount":1,"looping":true,"frameDelay":1,"version":"48WvIjYXVxyuCdt3Jah08koeLbeNGtRC","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":400,"y":399},"rootRelativePath":"assets/api/v1/animation-library/gamelab/48WvIjYXVxyuCdt3Jah08koeLbeNGtRC/category_backgrounds/background_landscape11.png"},"6b9462e5-dfcf-441c-9f20-524d652ba4c8":{"name":"rpgcharacter_24_1","sourceUrl":"assets/api/v1/animation-library/gamelab/y.68Vt3GwGvP_zt7tdcbGg0Vh4Gp9fpN/category_fantasy/rpgcharacter_24.png","frameSize":{"x":396,"y":222},"frameCount":1,"looping":true,"frameDelay":2,"version":"y.68Vt3GwGvP_zt7tdcbGg0Vh4Gp9fpN","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":396,"y":222},"rootRelativePath":"assets/api/v1/animation-library/gamelab/y.68Vt3GwGvP_zt7tdcbGg0Vh4Gp9fpN/category_fantasy/rpgcharacter_24.png"},"ebb12ed9-b027-4a88-8c4c-2cbabb86588c":{"name":"rpgcharacter_07_1","sourceUrl":"assets/api/v1/animation-library/gamelab/nuGcPmuvycktJ3yt6exTfjxaGLoA1pc_/category_fantasy/rpgcharacter_07.png","frameSize":{"x":282,"y":209},"frameCount":1,"looping":true,"frameDelay":2,"version":"nuGcPmuvycktJ3yt6exTfjxaGLoA1pc_","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":282,"y":209},"rootRelativePath":"assets/api/v1/animation-library/gamelab/nuGcPmuvycktJ3yt6exTfjxaGLoA1pc_/category_fantasy/rpgcharacter_07.png"},"86a08f63-af0a-4cc3-8ce2-0df5803643bc":{"name":"rpgcharacter_06_1","sourceUrl":"assets/api/v1/animation-library/gamelab/_YiuzeciqQNeKYmJiXDkwIdSsA6FT9FE/category_fantasy/rpgcharacter_06.png","frameSize":{"x":206,"y":237},"frameCount":1,"looping":true,"frameDelay":2,"version":"_YiuzeciqQNeKYmJiXDkwIdSsA6FT9FE","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":206,"y":237},"rootRelativePath":"assets/api/v1/animation-library/gamelab/_YiuzeciqQNeKYmJiXDkwIdSsA6FT9FE/category_fantasy/rpgcharacter_06.png"},"ce9914eb-bfbd-4140-8e2e-06a59aaa8fed":{"name":"rpgcharacter_05_1","sourceUrl":null,"frameSize":{"x":214,"y":209},"frameCount":2,"looping":true,"frameDelay":12,"version":"M0_4pJe2Q3tMGkuAGkWrjliNPRLoOmQW","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":214,"y":418},"rootRelativePath":"assets/ce9914eb-bfbd-4140-8e2e-06a59aaa8fed.png"},"dd7ed055-975a-4f2c-8b87-547bbee95b4c":{"name":"award_trophy1_1","sourceUrl":"assets/api/v1/animation-library/gamelab/qYuvwscvicUp26fkvQOaDTrPjKxv1BlU/category_video_games/award_trophy1.png","frameSize":{"x":312,"y":400},"frameCount":1,"looping":true,"frameDelay":2,"version":"qYuvwscvicUp26fkvQOaDTrPjKxv1BlU","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":312,"y":400},"rootRelativePath":"assets/api/v1/animation-library/gamelab/qYuvwscvicUp26fkvQOaDTrPjKxv1BlU/category_video_games/award_trophy1.png"},"1bf0370e-c715-44df-b29e-2a1d6f69a445":{"name":"rpgcharacter_05_2","sourceUrl":"assets/api/v1/animation-library/gamelab/NVWLyQ7eFA78l2aOE1XO4ZMdIKEXp338/category_fantasy/rpgcharacter_05.png","frameSize":{"x":214,"y":209},"frameCount":1,"looping":true,"frameDelay":2,"version":"NVWLyQ7eFA78l2aOE1XO4ZMdIKEXp338","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":214,"y":209},"rootRelativePath":"assets/api/v1/animation-library/gamelab/NVWLyQ7eFA78l2aOE1XO4ZMdIKEXp338/category_fantasy/rpgcharacter_05.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

  var background = createSprite(200,200);
  background.setAnimation("vestroia");
 
  var hero = createSprite(200,345,200,345);
  hero.shapeColor="red";

  var enemy1 = createSprite(200,250,10,10);
  enemy1.shapeColor="black";

  var enemy2 = createSprite(200,150,10,10);
  enemy2.shapeColor="black";

  var enemy3 = createSprite(200,50,10,10);
  enemy3.shapeColor="black";

  var trofhy = createSprite(200,5,200,20);
  trofhy.shapeColor="black";

  var goal =0;
  var death = 0;

  hero.setAnimation("rpgcharacter_24_1");
  hero.scale=0.2;

  enemy1.setAnimation("rpgcharacter_07_1");
  enemy1.scale=0.2;

  enemy2.setAnimation("rpgcharacter_06_1");
  enemy2.scale=0.2;

  enemy3.setAnimation("rpgcharacter_05_2");
  enemy3.scale=0.2;

  trofhy.setAnimation("award_trophy1_1");
  trofhy.scale=0.1;

  enemy1.velocityX = 8;
  enemy2.velocityX = -8;
  enemy3.velocityX = 8;

function draw() {
  
  

   createEdgeSprites();

   enemy1.bounceOff(edges);
   enemy2.bounceOff(edges);
   enemy3.bounceOff(edges);
   hero.bounceOff(edges);

    if(keyDown("w")){
    hero.y=hero.y-3;
  }

  if(keyDown("s")){
  hero.y=hero.y+3;
}

 if(keyDown("a")){
  hero.x=hero.x-3;
}

  if(keyDown("d")){
  hero.x=hero.x+3;
}
    if(keyDown("UP_ARROW")){
    hero.y=hero.y-3;
  }

  if(keyDown("DOWN_ARROW")){
  hero.y=hero.y+3;
}

 if(keyDown("LEFT_ARROW")){
  hero.x=hero.x-3;
}

  if(keyDown("RIGHT_ARROW")){
  hero.x=hero.x+3;
}
  if(hero.isTouching(enemy1)|| hero.isTouching(enemy2)|| hero.isTouching(enemy3)){
  playSound("assets/category_achievements/bubbly_game_achievement_sound.mp3");
  hero.x=200;
  hero.y=350;
  death = death+1;
}

  if(hero.isTouching(trofhy)){
  playSound("assets/category_achievements/vibrant_game_game_gold_tresure_chest_open.mp3");
  hero.x=200;
  hero.y=345;
  goal=goal+1;
}

  textSize(20);
  fill("blue");
  text("Objetivos:"+goal,320,350);
  

  textSize(20);
  fill("blue");
  text("mortes:"+death,20,350);
  
  drawSprites();
}


// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
